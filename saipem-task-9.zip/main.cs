/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
     /* int a=10;
      int b=12;
      if(a==b)
      {
          Console.WriteLine("is equal");
      }
      else
      {
          Console.WriteLine("Is not equal");
      }*/
      
      Console.Write("Enter fist value:");
      int c=Convert.ToInt32(Console.ReadLine());
      Console.Write("Enter secd value:");
      int d=Convert.ToInt32(Console.ReadLine());
      if(c==d)
      {
          Console.WriteLine("is equal");
      }
      else
      {
          Console.WriteLine("Is not equal");
      }
  }
}