/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class arithmatic{
    
}
class HelloWorld {
    
    public static void add(int num1,int num2){
        int result=num1+num2;
        Console.WriteLine("Addition of two num"+" "+result);
    } 
    
     public static void sub(int num1,int num2){
        int result=num1-num2;
        Console.WriteLine("substraction of two num"+" "+result);
    } 
    
     public static void mul(int num1,int num2){
        int result=num1*num2;
        Console.WriteLine("multiple of two num"+" "+result);
    } 
    
     public static void div(int num1,int num2){
        int result=num1/num2;
        Console.WriteLine("divison of two num"+" "+result);
    } 
    
    
  static void Main() {
      
    Console.WriteLine("Enter 1 for Addition:");
    Console.WriteLine("Enter 2 for substraction:");
    Console.WriteLine("Enter 3 for multiply:");
    Console.WriteLine("Enter 4 for divison:");
    
    
    int opr=Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Enter the firstnumber");
    int a=Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Enter the secondnumber");
    int b=Convert.ToInt32(Console.ReadLine());
    
    switch(opr)
    {
        case 1:
        add(a,b);
        break;
        
        case 2:
        sub(a,b);
        break;
        
        case 3:
        mul(a,b);
        break;
        
        case 4:
        div(a,b);
        break;
        
        default:
        Console.WriteLine("No record");
        break;
    }
  }
}