/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
      for(int i=1;i<=10;i++)
      {
          Console.Write(i+" ");
      }
      Console.WriteLine();
      for(int i=10;i>=1;i--)
      {
          Console.Write(i+" ");
      }
  }
}