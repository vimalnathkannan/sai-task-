/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
 
    public class father
    {
        public string name="kannan";
        public string native="mahathai";
        public string profession="welder";
        
    }
    
    public class sun1:father
    {
       public void vim()
       {
           Console.WriteLine("Enter the son details=");
       }
    }

    public class sun2:father
    {
        
    }
class HelloWorld {
    
  static void Main() {
      sun1 c1=new sun1();
      c1.vim();
      c1.name="vimal";
      c1.profession="web developer";
      Console.WriteLine(c1.name+" "+c1.native+" "+c1.profession);
    
      father c2=new father();
      Console.WriteLine(c2.name+" "+c2.native+" "+c2.profession);
    
       sun2 c3=new sun2();
       c3.name="vinoth";
       c3.profession="student";
       Console.WriteLine(c3.name+" "+c3.native+" "+c3.profession);
    
  }
}