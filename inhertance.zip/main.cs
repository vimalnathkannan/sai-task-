/******************************************************************************

                            Online C# Compiler.
                Code, Compile, Run and Debug C# program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
//multilevel
using System;
public class car
{
    public string model;
    public int year;
     
    
}
public class ford : car
{
    
    public string brand = "FORD";
    public void throatle()
    {
        Console.WriteLine(" vroom..vroom..");
    }
}

public class endevour:ford
{
   internal string type = "SUV";
    
}

class HelloWorld {
  static void Main() {
      endevour car1 = new endevour();
      Console.WriteLine(car1.brand);
      car1.model = "jhvh";
      car1.year = 2022;
        Console.WriteLine(car1.model+" "+car1.year+" "+car1.type);
    
  }
}

