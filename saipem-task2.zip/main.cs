/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
static class HelloWorld {
    public static int sno;
    public static string sname;
    public static string course;
    public static int fees;
    
    public static void meth1(int sNo,string sName,string Course,int Fees)
    {
        sno=sNo;
        sname=sName;
        course=Course;
        fees=Fees;
        Console.WriteLine("Your snum:"+sno);
        Console.WriteLine("Your name:"+sname);
        Console.WriteLine("Your course:"+course);
        Console.WriteLine("Your fees:"+fees);
        
    }
  static void Main() {
      Console.Write("Enter the sno:");
      int snum=Convert.ToInt32(Console.ReadLine());
      Console.Write("Enter the stu name:");
      string stunm=Console.ReadLine();
      Console.Write("Enter the course name:");
      string stuc=Console.ReadLine();
      Console.Write("Enter the fee details:");
      int stuF=Convert.ToInt32(Console.ReadLine());
      meth1(snum,stunm,stuc,stuF);
  }
}

