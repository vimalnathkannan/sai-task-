/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
      Console.Write("Enter the letter:");
      char name=Convert.ToChar(Console.ReadLine());
      
      switch(name)
      {
          case 'a':
          Console.WriteLine("given char is vowel");
          break;
          
          case 'e':
          Console.WriteLine("given char is vowel");
          break;
          
          case 'i':
          Console.WriteLine("given char is vowel");
          break;
          
          case 'o':
          Console.WriteLine("given char is vowel");
          break;
          
          case 'u':
          Console.WriteLine("given char is vowel");
          break;
          
          default:
          Console.WriteLine("Is not a vowel");
          break;
          
      }
  }
}
