/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
  static void Main() {
      
      Console.Write("Enter the letter : ");
      char name=Convert.ToChar(Console.ReadLine());
      
      if(name=='a' || name=='A')
      {
        Console.WriteLine("is a vowel letter");
      }
      else if(name=='e' || name=='E')
      {
          Console.WriteLine("is a vowel letter");
      }
      else if(name=='i' || name=='I')
      {
          Console.WriteLine("is a vowel letter");
      }
      else if(name=='o' || name=='O')
      {
          Console.WriteLine("is a vowel letter");
      }
      else if(name=='u' || name=='U')
      {
          Console.WriteLine("is a vowel letter");
      }
      else
      {
        Console.WriteLine("is not a letter");
      }
  }
}